function agregar(){
	var clave=;
	if (typeof(Storage)!=="undefined") {

                localStorage.setItem("Producto1","Curso Premium");
                localStorage.setItem("Producto2","Curso Normal");
                localStorage.setItem("Producto3","Curso Pobre");
            }


}